/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.LayerDrawable
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.OvalShape
 *  android.graphics.drawable.shapes.Shape
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.DisplayMetrics
 *  android.util.SparseArray
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.DecelerateInterpolator
 *  com.google.android.gms.maps.GoogleMap
 *  com.google.android.gms.maps.GoogleMap$OnInfoWindowClickListener
 *  com.google.android.gms.maps.GoogleMap$OnMarkerClickListener
 *  com.google.android.gms.maps.model.BitmapDescriptor
 *  com.google.android.gms.maps.model.BitmapDescriptorFactory
 *  com.google.android.gms.maps.model.Marker
 *  com.google.android.gms.maps.model.MarkerOptions
 *  com.google.maps.android.MarkerManager$Collection
 *  com.google.maps.android.R
 *  com.google.maps.android.R$id
 *  com.google.maps.android.R$style
 *  com.google.maps.android.clustering.Cluster
 *  com.google.maps.android.clustering.ClusterItem
 *  com.google.maps.android.clustering.ClusterManager$OnClusterClickListener
 *  com.google.maps.android.clustering.ClusterManager$OnClusterInfoWindowClickListener
 *  com.google.maps.android.clustering.ClusterManager$OnClusterItemClickListener
 *  com.google.maps.android.clustering.ClusterManager$OnClusterItemInfoWindowClickListener
 *  com.google.maps.android.clustering.view.ClusterRenderer
 *  com.google.maps.android.clustering.view.DefaultClusterRenderer$MarkerCache
 *  com.google.maps.android.clustering.view.DefaultClusterRenderer$MarkerWithPosition
 *  com.google.maps.android.clustering.view.DefaultClusterRenderer$ViewModifier
 *  com.google.maps.android.geometry.Point
 *  com.google.maps.android.ui.IconGenerator
 *  com.google.maps.android.ui.SquareTextView
 *  java.lang.CharSequence
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 */
package com.google.maps.android.clustering.view;

import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.Shape;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.MarkerManager;
import com.google.maps.android.R;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterItem;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.ClusterRenderer;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.google.maps.android.geometry.Point;
import com.google.maps.android.ui.IconGenerator;
import com.google.maps.android.ui.SquareTextView;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/*
 * Exception performing whole class analysis.
 */
public class DefaultClusterRenderer<T extends ClusterItem>
implements ClusterRenderer<T> {
    private static final TimeInterpolator ANIMATION_INTERP;
    private static final int[] BUCKETS;
    private static final boolean SHOULD_ANIMATE;
    private ClusterManager.OnClusterClickListener<T> mClickListener;
    private final ClusterManager<T> mClusterManager;
    private Map<Cluster<T>, Marker> mClusterToMarker;
    private Set<? extends Cluster<T>> mClusters;
    private ShapeDrawable mColoredCircleBackground;
    private final float mDensity;
    private final IconGenerator mIconGenerator;
    private SparseArray<BitmapDescriptor> mIcons;
    private ClusterManager.OnClusterInfoWindowClickListener<T> mInfoWindowClickListener;
    private ClusterManager.OnClusterItemClickListener<T> mItemClickListener;
    private ClusterManager.OnClusterItemInfoWindowClickListener<T> mItemInfoWindowClickListener;
    private final GoogleMap mMap;
    private MarkerCache<T> mMarkerCache;
    private Map<Marker, Cluster<T>> mMarkerToCluster;
    private Set<MarkerWithPosition> mMarkers;
    private int mMinClusterSize;
    private final DefaultClusterRenderer<T> mViewModifier;
    private float mZoom;

    static {
        boolean bl = Build.VERSION.SDK_INT >= 11;
        SHOULD_ANIMATE = bl;
        BUCKETS = new int[]{10, 20, 50, 100, 200, 500, 1000};
        ANIMATION_INTERP = new DecelerateInterpolator();
    }

    public DefaultClusterRenderer(Context context, GoogleMap googleMap, ClusterManager<T> clusterManager) {
        this.mMarkers = Collections.newSetFromMap((Map)new ConcurrentHashMap());
        this.mIcons = new SparseArray();
        this.mMarkerCache = new /* Unavailable Anonymous Inner Class!! */;
        this.mMinClusterSize = 4;
        this.mMarkerToCluster = new HashMap();
        this.mClusterToMarker = new HashMap();
        this.mViewModifier = new /* Unavailable Anonymous Inner Class!! */;
        this.mMap = googleMap;
        this.mDensity = context.getResources().getDisplayMetrics().density;
        this.mIconGenerator = new IconGenerator(context);
        this.mIconGenerator.setContentView((View)DefaultClusterRenderer.super.makeSquareTextView(context));
        this.mIconGenerator.setTextAppearance(R.style.amu_ClusterIcon_TextAppearance);
        this.mIconGenerator.setBackground((Drawable)DefaultClusterRenderer.super.makeClusterBackground());
        this.mClusterManager = clusterManager;
    }

    static /* synthetic */ float access$1000(DefaultClusterRenderer defaultClusterRenderer) {
        return defaultClusterRenderer.mZoom;
    }

    static /* synthetic */ float access$1002(DefaultClusterRenderer defaultClusterRenderer, float f) {
        defaultClusterRenderer.mZoom = f;
        return f;
    }

    static /* synthetic */ Set access$1100(DefaultClusterRenderer defaultClusterRenderer) {
        return defaultClusterRenderer.mClusters;
    }

    static /* synthetic */ Set access$1102(DefaultClusterRenderer defaultClusterRenderer, Set set) {
        defaultClusterRenderer.mClusters = set;
        return set;
    }

    static /* synthetic */ Set access$1300(DefaultClusterRenderer defaultClusterRenderer) {
        return defaultClusterRenderer.mMarkers;
    }

    static /* synthetic */ Set access$1302(DefaultClusterRenderer defaultClusterRenderer, Set set) {
        defaultClusterRenderer.mMarkers = set;
        return set;
    }

    static /* synthetic */ boolean access$1400() {
        return SHOULD_ANIMATE;
    }

    static /* synthetic */ Point access$1500(List list, Point point) {
        return DefaultClusterRenderer.findClosestCluster((List<Point>)list, point);
    }

    static /* synthetic */ ClusterManager access$1900(DefaultClusterRenderer defaultClusterRenderer) {
        return defaultClusterRenderer.mClusterManager;
    }

    static /* synthetic */ Map access$2100(DefaultClusterRenderer defaultClusterRenderer) {
        return defaultClusterRenderer.mClusterToMarker;
    }

    static /* synthetic */ TimeInterpolator access$2300() {
        return ANIMATION_INTERP;
    }

    static /* synthetic */ GoogleMap access$800(DefaultClusterRenderer defaultClusterRenderer) {
        return defaultClusterRenderer.mMap;
    }

    private static double distanceSquared(Point point, Point point2) {
        return (point.x - point2.x) * (point.x - point2.x) + (point.y - point2.y) * (point.y - point2.y);
    }

    private static Point findClosestCluster(List<Point> list, Point point) {
        Point point2 = null;
        if (list != null) {
            if (list.isEmpty()) {
                return null;
            }
            double d = 10000.0;
            for (Point point3 : list) {
                double d2 = DefaultClusterRenderer.distanceSquared(point3, point);
                if (!(d2 < d)) continue;
                point2 = point3;
                d = d2;
            }
            return point2;
        }
        return null;
    }

    private LayerDrawable makeClusterBackground() {
        this.mColoredCircleBackground = new ShapeDrawable((Shape)new OvalShape());
        ShapeDrawable shapeDrawable = new ShapeDrawable((Shape)new OvalShape());
        shapeDrawable.getPaint().setColor(-2130706433);
        Drawable[] arrdrawable = new Drawable[]{shapeDrawable, this.mColoredCircleBackground};
        LayerDrawable layerDrawable = new LayerDrawable(arrdrawable);
        int n = (int)(3.0f * this.mDensity);
        layerDrawable.setLayerInset(1, n, n, n, n);
        return layerDrawable;
    }

    private SquareTextView makeSquareTextView(Context context) {
        SquareTextView squareTextView = new SquareTextView(context);
        squareTextView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        squareTextView.setId(R.id.amu_text);
        int n = (int)(12.0f * this.mDensity);
        squareTextView.setPadding(n, n, n, n);
        return squareTextView;
    }

    protected int getBucket(Cluster<T> cluster) {
        int n = cluster.getSize();
        int n2 = BUCKETS[0];
        int n3 = 0;
        if (n <= n2) {
            return n;
        }
        while (n3 < -1 + BUCKETS.length) {
            int[] arrn = BUCKETS;
            int n4 = n3 + 1;
            if (n < arrn[n4]) {
                return BUCKETS[n3];
            }
            n3 = n4;
        }
        return BUCKETS[-1 + BUCKETS.length];
    }

    public Cluster<T> getCluster(Marker marker) {
        return (Cluster)this.mMarkerToCluster.get((Object)marker);
    }

    public T getClusterItem(Marker marker) {
        return (T)((ClusterItem)this.mMarkerCache.get(marker));
    }

    protected String getClusterText(int n) {
        if (n < BUCKETS[0]) {
            return String.valueOf((int)n);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.valueOf((int)n));
        stringBuilder.append("+");
        return stringBuilder.toString();
    }

    protected int getColor(int n) {
        float f = 300.0f - Math.min((float)n, (float)300.0f);
        return Color.HSVToColor((float[])new float[]{220.0f * (f * f / 90000.0f), 1.0f, 0.6f});
    }

    public Marker getMarker(Cluster<T> cluster) {
        return (Marker)this.mClusterToMarker.get(cluster);
    }

    public Marker getMarker(T t) {
        return this.mMarkerCache.get(t);
    }

    public int getMinClusterSize() {
        return this.mMinClusterSize;
    }

    public void onAdd() {
        this.mClusterManager.getMarkerCollection().setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener(){

            public boolean onMarkerClick(Marker marker) {
                return DefaultClusterRenderer.this.mItemClickListener != null && DefaultClusterRenderer.this.mItemClickListener.onClusterItemClick((ClusterItem)DefaultClusterRenderer.this.mMarkerCache.get(marker));
            }
        });
        this.mClusterManager.getMarkerCollection().setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener(){

            public void onInfoWindowClick(Marker marker) {
                if (DefaultClusterRenderer.this.mItemInfoWindowClickListener != null) {
                    DefaultClusterRenderer.this.mItemInfoWindowClickListener.onClusterItemInfoWindowClick((ClusterItem)DefaultClusterRenderer.this.mMarkerCache.get(marker));
                }
            }
        });
        this.mClusterManager.getClusterMarkerCollection().setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener(){

            public boolean onMarkerClick(Marker marker) {
                return DefaultClusterRenderer.this.mClickListener != null && DefaultClusterRenderer.this.mClickListener.onClusterClick((Cluster)DefaultClusterRenderer.this.mMarkerToCluster.get((Object)marker));
            }
        });
        this.mClusterManager.getClusterMarkerCollection().setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener(){

            public void onInfoWindowClick(Marker marker) {
                if (DefaultClusterRenderer.this.mInfoWindowClickListener != null) {
                    DefaultClusterRenderer.this.mInfoWindowClickListener.onClusterInfoWindowClick((Cluster)DefaultClusterRenderer.this.mMarkerToCluster.get((Object)marker));
                }
            }
        });
    }

    protected void onBeforeClusterItemRendered(T t, MarkerOptions markerOptions) {
    }

    protected void onBeforeClusterRendered(Cluster<T> cluster, MarkerOptions markerOptions) {
        int n = this.getBucket(cluster);
        BitmapDescriptor bitmapDescriptor = (BitmapDescriptor)this.mIcons.get(n);
        if (bitmapDescriptor == null) {
            this.mColoredCircleBackground.getPaint().setColor(this.getColor(n));
            bitmapDescriptor = BitmapDescriptorFactory.fromBitmap((Bitmap)this.mIconGenerator.makeIcon((CharSequence)this.getClusterText(n)));
            this.mIcons.put(n, (Object)bitmapDescriptor);
        }
        markerOptions.icon(bitmapDescriptor);
    }

    protected void onClusterItemRendered(T t, Marker marker) {
    }

    protected void onClusterRendered(Cluster<T> cluster, Marker marker) {
    }

    public void onClustersChanged(Set<? extends Cluster<T>> set) {
        this.mViewModifier.queue(set);
    }

    public void onRemove() {
        this.mClusterManager.getMarkerCollection().setOnMarkerClickListener(null);
        this.mClusterManager.getClusterMarkerCollection().setOnMarkerClickListener(null);
    }

    public void setMinClusterSize(int n) {
        this.mMinClusterSize = n;
    }

    public void setOnClusterClickListener(ClusterManager.OnClusterClickListener<T> onClusterClickListener) {
        this.mClickListener = onClusterClickListener;
    }

    public void setOnClusterInfoWindowClickListener(ClusterManager.OnClusterInfoWindowClickListener<T> onClusterInfoWindowClickListener) {
        this.mInfoWindowClickListener = onClusterInfoWindowClickListener;
    }

    public void setOnClusterItemClickListener(ClusterManager.OnClusterItemClickListener<T> onClusterItemClickListener) {
        this.mItemClickListener = onClusterItemClickListener;
    }

    public void setOnClusterItemInfoWindowClickListener(ClusterManager.OnClusterItemInfoWindowClickListener<T> onClusterItemInfoWindowClickListener) {
        this.mItemInfoWindowClickListener = onClusterItemInfoWindowClickListener;
    }

    protected boolean shouldRenderAsCluster(Cluster<T> cluster) {
        return cluster.getSize() > this.mMinClusterSize;
    }

}

