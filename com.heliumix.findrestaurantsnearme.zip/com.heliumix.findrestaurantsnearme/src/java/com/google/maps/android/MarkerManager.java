/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.google.android.gms.maps.GoogleMap
 *  com.google.android.gms.maps.GoogleMap$InfoWindowAdapter
 *  com.google.android.gms.maps.GoogleMap$OnInfoWindowClickListener
 *  com.google.android.gms.maps.GoogleMap$OnMarkerClickListener
 *  com.google.android.gms.maps.GoogleMap$OnMarkerDragListener
 *  com.google.android.gms.maps.model.Marker
 *  com.google.maps.android.MarkerManager$Collection
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.maps.android;

import android.view.View;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;
import com.google.maps.android.MarkerManager;
import java.util.HashMap;
import java.util.Map;

/*
 * Exception performing whole class analysis.
 * Exception performing whole class analysis ignored.
 */
public class MarkerManager
implements GoogleMap.OnInfoWindowClickListener,
GoogleMap.OnMarkerClickListener,
GoogleMap.OnMarkerDragListener,
GoogleMap.InfoWindowAdapter {
    private final Map<Marker, Collection> mAllMarkers;
    private final GoogleMap mMap;
    private final Map<String, Collection> mNamedCollections;

    public MarkerManager(GoogleMap googleMap) {
        this.mNamedCollections = new HashMap();
        this.mAllMarkers = new HashMap();
        this.mMap = googleMap;
    }

    static /* synthetic */ GoogleMap access$400(MarkerManager markerManager) {
        return markerManager.mMap;
    }

    static /* synthetic */ Map access$500(MarkerManager markerManager) {
        return markerManager.mAllMarkers;
    }

    public Collection getCollection(String string) {
        return this.mNamedCollections.get((Object)string);
    }

    public View getInfoContents(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        if (collection != null && Collection.access$000(collection) != null) {
            return Collection.access$000(collection).getInfoContents(marker);
        }
        return null;
    }

    public View getInfoWindow(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        if (collection != null && Collection.access$000(collection) != null) {
            return Collection.access$000(collection).getInfoWindow(marker);
        }
        return null;
    }

    public Collection newCollection() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public Collection newCollection(String string) {
        if (this.mNamedCollections.get((Object)string) != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("collection id is not unique: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        Collection collection = new /* Unavailable Anonymous Inner Class!! */;
        this.mNamedCollections.put((Object)string, (Object)collection);
        return collection;
    }

    public void onInfoWindowClick(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        if (collection != null && Collection.access$100(collection) != null) {
            Collection.access$100(collection).onInfoWindowClick(marker);
        }
    }

    public boolean onMarkerClick(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        if (collection != null && Collection.access$200(collection) != null) {
            return Collection.access$200(collection).onMarkerClick(marker);
        }
        return false;
    }

    public void onMarkerDrag(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        if (collection != null && Collection.access$300(collection) != null) {
            Collection.access$300(collection).onMarkerDrag(marker);
        }
    }

    public void onMarkerDragEnd(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        if (collection != null && Collection.access$300(collection) != null) {
            Collection.access$300(collection).onMarkerDragEnd(marker);
        }
    }

    public void onMarkerDragStart(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        if (collection != null && Collection.access$300(collection) != null) {
            Collection.access$300(collection).onMarkerDragStart(marker);
        }
    }

    public boolean remove(Marker marker) {
        Collection collection = this.mAllMarkers.get((Object)marker);
        return collection != null && collection.remove(marker);
    }
}

