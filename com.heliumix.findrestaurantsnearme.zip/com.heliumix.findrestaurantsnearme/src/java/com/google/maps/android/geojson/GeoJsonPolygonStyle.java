/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.PolygonOptions
 *  com.google.maps.android.geojson.GeoJsonStyle
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Observable
 */
package com.google.maps.android.geojson;

import com.google.android.gms.maps.model.PolygonOptions;
import com.google.maps.android.geojson.GeoJsonStyle;
import java.util.Arrays;
import java.util.Observable;

public class GeoJsonPolygonStyle
extends Observable
implements GeoJsonStyle {
    private static final String[] GEOMETRY_TYPE = new String[]{"Polygon", "MultiPolygon", "GeometryCollection"};
    private final PolygonOptions mPolygonOptions = new PolygonOptions();

    private void styleChanged() {
        this.setChanged();
        this.notifyObservers();
    }

    public int getFillColor() {
        return this.mPolygonOptions.getFillColor();
    }

    public String[] getGeometryType() {
        return GEOMETRY_TYPE;
    }

    public int getStrokeColor() {
        return this.mPolygonOptions.getStrokeColor();
    }

    public float getStrokeWidth() {
        return this.mPolygonOptions.getStrokeWidth();
    }

    public float getZIndex() {
        return this.mPolygonOptions.getZIndex();
    }

    public boolean isGeodesic() {
        return this.mPolygonOptions.isGeodesic();
    }

    public boolean isVisible() {
        return this.mPolygonOptions.isVisible();
    }

    public void setFillColor(int n) {
        this.mPolygonOptions.fillColor(n);
        GeoJsonPolygonStyle.super.styleChanged();
    }

    public void setGeodesic(boolean bl) {
        this.mPolygonOptions.geodesic(bl);
        GeoJsonPolygonStyle.super.styleChanged();
    }

    public void setStrokeColor(int n) {
        this.mPolygonOptions.strokeColor(n);
        GeoJsonPolygonStyle.super.styleChanged();
    }

    public void setStrokeWidth(float f) {
        this.mPolygonOptions.strokeWidth(f);
        GeoJsonPolygonStyle.super.styleChanged();
    }

    public void setVisible(boolean bl) {
        this.mPolygonOptions.visible(bl);
        GeoJsonPolygonStyle.super.styleChanged();
    }

    public void setZIndex(float f) {
        this.mPolygonOptions.zIndex(f);
        GeoJsonPolygonStyle.super.styleChanged();
    }

    public PolygonOptions toPolygonOptions() {
        PolygonOptions polygonOptions = new PolygonOptions();
        polygonOptions.fillColor(this.mPolygonOptions.getFillColor());
        polygonOptions.geodesic(this.mPolygonOptions.isGeodesic());
        polygonOptions.strokeColor(this.mPolygonOptions.getStrokeColor());
        polygonOptions.strokeWidth(this.mPolygonOptions.getStrokeWidth());
        polygonOptions.visible(this.mPolygonOptions.isVisible());
        polygonOptions.zIndex(this.mPolygonOptions.getZIndex());
        return polygonOptions;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("PolygonStyle{");
        stringBuilder.append("\n geometry type=");
        stringBuilder.append(Arrays.toString((Object[])GEOMETRY_TYPE));
        stringBuilder.append(",\n fill color=");
        stringBuilder.append(this.getFillColor());
        stringBuilder.append(",\n geodesic=");
        stringBuilder.append(this.isGeodesic());
        stringBuilder.append(",\n stroke color=");
        stringBuilder.append(this.getStrokeColor());
        stringBuilder.append(",\n stroke width=");
        stringBuilder.append(this.getStrokeWidth());
        stringBuilder.append(",\n visible=");
        stringBuilder.append(this.isVisible());
        stringBuilder.append(",\n z index=");
        stringBuilder.append(this.getZIndex());
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

