/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.maps.android.geometry.Point
 *  java.lang.Deprecated
 */
package com.google.maps.android.projection;

@Deprecated
public class Point
extends com.google.maps.android.geometry.Point {
    public Point(double d, double d2) {
        super(d, d2);
    }
}

