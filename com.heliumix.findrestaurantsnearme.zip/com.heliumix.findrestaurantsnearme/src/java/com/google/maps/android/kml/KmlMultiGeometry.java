/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.maps.android.kml.KmlGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.google.maps.android.kml;

import com.google.maps.android.kml.KmlGeometry;
import java.util.ArrayList;

public class KmlMultiGeometry
implements KmlGeometry<ArrayList<KmlGeometry>> {
    private static final String GEOMETRY_TYPE = "MultiGeometry";
    private ArrayList<KmlGeometry> mGeometries = new ArrayList();

    public KmlMultiGeometry(ArrayList<KmlGeometry> arrayList) {
        if (arrayList == null) {
            throw new IllegalArgumentException("Geometries cannot be null");
        }
        this.mGeometries = arrayList;
    }

    public ArrayList<KmlGeometry> getGeometryObject() {
        return this.mGeometries;
    }

    public String getGeometryType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n geometries=");
        stringBuilder.append(this.mGeometries);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

