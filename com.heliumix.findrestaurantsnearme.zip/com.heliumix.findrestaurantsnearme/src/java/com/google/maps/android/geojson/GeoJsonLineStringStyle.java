/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.PolylineOptions
 *  com.google.maps.android.geojson.GeoJsonStyle
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Observable
 */
package com.google.maps.android.geojson;

import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.geojson.GeoJsonStyle;
import java.util.Arrays;
import java.util.Observable;

public class GeoJsonLineStringStyle
extends Observable
implements GeoJsonStyle {
    private static final String[] GEOMETRY_TYPE = new String[]{"LineString", "MultiLineString", "GeometryCollection"};
    private final PolylineOptions mPolylineOptions = new PolylineOptions();

    private void styleChanged() {
        this.setChanged();
        this.notifyObservers();
    }

    public int getColor() {
        return this.mPolylineOptions.getColor();
    }

    public String[] getGeometryType() {
        return GEOMETRY_TYPE;
    }

    public float getWidth() {
        return this.mPolylineOptions.getWidth();
    }

    public float getZIndex() {
        return this.mPolylineOptions.getZIndex();
    }

    public boolean isClickable() {
        return this.mPolylineOptions.isClickable();
    }

    public boolean isGeodesic() {
        return this.mPolylineOptions.isGeodesic();
    }

    public boolean isVisible() {
        return this.mPolylineOptions.isVisible();
    }

    public void setClickable(boolean bl) {
        this.mPolylineOptions.clickable(bl);
        GeoJsonLineStringStyle.super.styleChanged();
    }

    public void setColor(int n) {
        this.mPolylineOptions.color(n);
        GeoJsonLineStringStyle.super.styleChanged();
    }

    public void setGeodesic(boolean bl) {
        this.mPolylineOptions.geodesic(bl);
        GeoJsonLineStringStyle.super.styleChanged();
    }

    public void setVisible(boolean bl) {
        this.mPolylineOptions.visible(bl);
        GeoJsonLineStringStyle.super.styleChanged();
    }

    public void setWidth(float f) {
        this.mPolylineOptions.width(f);
        GeoJsonLineStringStyle.super.styleChanged();
    }

    public void setZIndex(float f) {
        this.mPolylineOptions.zIndex(f);
        GeoJsonLineStringStyle.super.styleChanged();
    }

    public PolylineOptions toPolylineOptions() {
        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.color(this.mPolylineOptions.getColor());
        polylineOptions.clickable(this.mPolylineOptions.isClickable());
        polylineOptions.geodesic(this.mPolylineOptions.isGeodesic());
        polylineOptions.visible(this.mPolylineOptions.isVisible());
        polylineOptions.width(this.mPolylineOptions.getWidth());
        polylineOptions.zIndex(this.mPolylineOptions.getZIndex());
        return polylineOptions;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("LineStringStyle{");
        stringBuilder.append("\n geometry type=");
        stringBuilder.append(Arrays.toString((Object[])GEOMETRY_TYPE));
        stringBuilder.append(",\n color=");
        stringBuilder.append(this.getColor());
        stringBuilder.append(",\n clickable=");
        stringBuilder.append(this.isClickable());
        stringBuilder.append(",\n geodesic=");
        stringBuilder.append(this.isGeodesic());
        stringBuilder.append(",\n visible=");
        stringBuilder.append(this.isVisible());
        stringBuilder.append(",\n width=");
        stringBuilder.append(this.getWidth());
        stringBuilder.append(",\n z index=");
        stringBuilder.append(this.getZIndex());
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

