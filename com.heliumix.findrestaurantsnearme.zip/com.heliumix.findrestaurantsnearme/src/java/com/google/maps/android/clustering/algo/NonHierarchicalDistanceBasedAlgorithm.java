/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.clustering.Cluster
 *  com.google.maps.android.clustering.ClusterItem
 *  com.google.maps.android.clustering.algo.Algorithm
 *  com.google.maps.android.clustering.algo.NonHierarchicalDistanceBasedAlgorithm$1
 *  com.google.maps.android.geometry.Bounds
 *  com.google.maps.android.geometry.Point
 *  com.google.maps.android.projection.SphericalMercatorProjection
 *  com.google.maps.android.quadtree.PointQuadTree
 *  com.google.maps.android.quadtree.PointQuadTree$Item
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 */
package com.google.maps.android.clustering.algo;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterItem;
import com.google.maps.android.clustering.algo.Algorithm;
import com.google.maps.android.clustering.algo.NonHierarchicalDistanceBasedAlgorithm;
import com.google.maps.android.clustering.algo.StaticCluster;
import com.google.maps.android.geometry.Bounds;
import com.google.maps.android.geometry.Point;
import com.google.maps.android.projection.SphericalMercatorProjection;
import com.google.maps.android.quadtree.PointQuadTree;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class NonHierarchicalDistanceBasedAlgorithm<T extends ClusterItem>
implements Algorithm<T> {
    public static final int MAX_DISTANCE_AT_ZOOM = 100;
    private static final SphericalMercatorProjection PROJECTION = new SphericalMercatorProjection(1.0);
    private final Collection<QuadItem<T>> mItems = new ArrayList();
    private final PointQuadTree<QuadItem<T>> mQuadTree;

    public NonHierarchicalDistanceBasedAlgorithm() {
        PointQuadTree pointQuadTree;
        this.mQuadTree = pointQuadTree = new PointQuadTree(0.0, 1.0, 0.0, 1.0);
    }

    private Bounds createBoundsFromSpan(Point point, double d) {
        double d2 = d / 2.0;
        Bounds bounds = new Bounds(point.x - d2, d2 + point.x, point.y - d2, d2 + point.y);
        return bounds;
    }

    private double distanceSquared(Point point, Point point2) {
        return (point.x - point2.x) * (point.x - point2.x) + (point.y - point2.y) * (point.y - point2.y);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void addItem(T t) {
        PointQuadTree<QuadItem<T>> pointQuadTree;
        QuadItem quadItem = new QuadItem((ClusterItem)t, null);
        PointQuadTree<QuadItem<T>> pointQuadTree2 = pointQuadTree = this.mQuadTree;
        synchronized (pointQuadTree2) {
            this.mItems.add(quadItem);
            this.mQuadTree.add(quadItem);
            return;
        }
    }

    public void addItems(Collection<T> collection) {
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            this.addItem((T)((ClusterItem)iterator.next()));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void clearItems() {
        PointQuadTree<QuadItem<T>> pointQuadTree;
        PointQuadTree<QuadItem<T>> pointQuadTree2 = pointQuadTree = this.mQuadTree;
        synchronized (pointQuadTree2) {
            this.mItems.clear();
            this.mQuadTree.clear();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Set<? extends Cluster<T>> getClusters(double d) {
        PointQuadTree<QuadItem<T>> pointQuadTree;
        void var3_2 = this;
        double d2 = 100.0 / Math.pow((double)2.0, (double)((int)d)) / 256.0;
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        HashMap hashMap = new HashMap();
        HashMap hashMap2 = new HashMap();
        PointQuadTree<QuadItem<T>> pointQuadTree2 = pointQuadTree = var3_2.mQuadTree;
        synchronized (pointQuadTree2) {
            Iterator iterator = var3_2.mItems.iterator();
            while (iterator.hasNext()) {
                QuadItem quadItem = (QuadItem)iterator.next();
                if (hashSet.contains((Object)quadItem)) continue;
                Bounds bounds = NonHierarchicalDistanceBasedAlgorithm.super.createBoundsFromSpan(quadItem.getPoint(), d2);
                Collection collection = var3_2.mQuadTree.search(bounds);
                if (collection.size() == 1) {
                    hashSet2.add((Object)quadItem);
                    hashSet.add((Object)quadItem);
                    hashMap.put((Object)quadItem, (Object)0.0);
                    continue;
                }
                StaticCluster<ClusterItem> staticCluster = new StaticCluster<ClusterItem>(quadItem.mClusterItem.getPosition());
                hashSet2.add(staticCluster);
                for (QuadItem quadItem2 : collection) {
                    Double d3 = (Double)hashMap.get((Object)quadItem2);
                    double d4 = d2;
                    double d5 = NonHierarchicalDistanceBasedAlgorithm.super.distanceSquared(quadItem2.getPoint(), quadItem.getPoint());
                    if (d3 != null) {
                        if (d3 < d5) {
                            d2 = d4;
                            continue;
                        }
                        ((StaticCluster)hashMap2.get((Object)quadItem2)).remove(quadItem2.mClusterItem);
                    }
                    hashMap.put((Object)quadItem2, (Object)d5);
                    staticCluster.add(quadItem2.mClusterItem);
                    hashMap2.put((Object)quadItem2, staticCluster);
                    d2 = d4;
                    var3_2 = this;
                }
                double d6 = d2;
                hashSet.addAll(collection);
                d2 = d6;
                var3_2 = this;
            }
            return hashSet2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Collection<T> getItems() {
        PointQuadTree<QuadItem<T>> pointQuadTree;
        ArrayList arrayList = new ArrayList();
        PointQuadTree<QuadItem<T>> pointQuadTree2 = pointQuadTree = this.mQuadTree;
        synchronized (pointQuadTree2) {
            Iterator iterator = this.mItems.iterator();
            while (iterator.hasNext()) {
                arrayList.add((Object)((QuadItem)iterator.next()).mClusterItem);
            }
            return arrayList;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void removeItem(T t) {
        PointQuadTree<QuadItem<T>> pointQuadTree;
        QuadItem quadItem = new QuadItem((ClusterItem)t, null);
        PointQuadTree<QuadItem<T>> pointQuadTree2 = pointQuadTree = this.mQuadTree;
        synchronized (pointQuadTree2) {
            this.mItems.remove(quadItem);
            this.mQuadTree.remove(quadItem);
            return;
        }
    }

    private static class QuadItem<T extends ClusterItem>
    implements PointQuadTree.Item,
    Cluster<T> {
        private final T mClusterItem;
        private final Point mPoint;
        private final LatLng mPosition;
        private Set<T> singletonSet;

        private QuadItem(T t) {
            this.mClusterItem = t;
            this.mPosition = t.getPosition();
            this.mPoint = PROJECTION.toPoint(this.mPosition);
            this.singletonSet = Collections.singleton(this.mClusterItem);
        }

        /* synthetic */ QuadItem(ClusterItem clusterItem, 1 var2_2) {
            super((T)clusterItem);
        }

        public boolean equals(Object object) {
            if (!(object instanceof QuadItem)) {
                return false;
            }
            return ((QuadItem)object).mClusterItem.equals(this.mClusterItem);
        }

        public Set<T> getItems() {
            return this.singletonSet;
        }

        public Point getPoint() {
            return this.mPoint;
        }

        public LatLng getPosition() {
            return this.mPosition;
        }

        public int getSize() {
            return 1;
        }

        public int hashCode() {
            return this.mClusterItem.hashCode();
        }
    }

}

