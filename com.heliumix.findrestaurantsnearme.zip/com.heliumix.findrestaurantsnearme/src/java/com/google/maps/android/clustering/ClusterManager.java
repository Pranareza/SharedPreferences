/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.AsyncTask
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.google.android.gms.maps.GoogleMap
 *  com.google.android.gms.maps.GoogleMap$OnCameraIdleListener
 *  com.google.android.gms.maps.GoogleMap$OnInfoWindowClickListener
 *  com.google.android.gms.maps.GoogleMap$OnMarkerClickListener
 *  com.google.android.gms.maps.model.CameraPosition
 *  com.google.android.gms.maps.model.Marker
 *  com.google.maps.android.MarkerManager$Collection
 *  com.google.maps.android.clustering.ClusterItem
 *  com.google.maps.android.clustering.ClusterManager$1
 *  com.google.maps.android.clustering.ClusterManager$ClusterTask
 *  com.google.maps.android.clustering.ClusterManager$OnClusterClickListener
 *  com.google.maps.android.clustering.ClusterManager$OnClusterInfoWindowClickListener
 *  com.google.maps.android.clustering.ClusterManager$OnClusterItemClickListener
 *  com.google.maps.android.clustering.ClusterManager$OnClusterItemInfoWindowClickListener
 *  com.google.maps.android.clustering.algo.Algorithm
 *  com.google.maps.android.clustering.view.ClusterRenderer
 *  java.lang.Float
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.concurrent.Executor
 *  java.util.concurrent.locks.Lock
 *  java.util.concurrent.locks.ReadWriteLock
 *  java.util.concurrent.locks.ReentrantReadWriteLock
 */
package com.google.maps.android.clustering;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Marker;
import com.google.maps.android.MarkerManager;
import com.google.maps.android.clustering.ClusterItem;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.algo.Algorithm;
import com.google.maps.android.clustering.algo.NonHierarchicalDistanceBasedAlgorithm;
import com.google.maps.android.clustering.algo.PreCachingAlgorithmDecorator;
import com.google.maps.android.clustering.view.ClusterRenderer;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import java.util.Collection;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/*
 * Exception performing whole class analysis.
 */
public class ClusterManager<T extends ClusterItem>
implements GoogleMap.OnCameraIdleListener,
GoogleMap.OnMarkerClickListener,
GoogleMap.OnInfoWindowClickListener {
    private Algorithm<T> mAlgorithm;
    private final ReadWriteLock mAlgorithmLock;
    private final MarkerManager.Collection mClusterMarkers;
    private ClusterManager<T> mClusterTask;
    private final ReadWriteLock mClusterTaskLock;
    private GoogleMap mMap;
    private final MarkerManager mMarkerManager;
    private final MarkerManager.Collection mMarkers;
    private OnClusterClickListener<T> mOnClusterClickListener;
    private OnClusterInfoWindowClickListener<T> mOnClusterInfoWindowClickListener;
    private OnClusterItemClickListener<T> mOnClusterItemClickListener;
    private OnClusterItemInfoWindowClickListener<T> mOnClusterItemInfoWindowClickListener;
    private CameraPosition mPreviousCameraPosition;
    private ClusterRenderer<T> mRenderer;

    public ClusterManager(Context context, GoogleMap googleMap) {
        super(context, googleMap, new MarkerManager(googleMap));
    }

    public ClusterManager(Context context, GoogleMap googleMap, MarkerManager markerManager) {
        this.mAlgorithmLock = new ReentrantReadWriteLock();
        this.mClusterTaskLock = new ReentrantReadWriteLock();
        this.mMap = googleMap;
        this.mMarkerManager = markerManager;
        this.mClusterMarkers = markerManager.newCollection();
        this.mMarkers = markerManager.newCollection();
        this.mRenderer = new DefaultClusterRenderer(context, googleMap, this);
        this.mAlgorithm = new PreCachingAlgorithmDecorator(new NonHierarchicalDistanceBasedAlgorithm());
        this.mClusterTask = new /* Unavailable Anonymous Inner Class!! */;
        this.mRenderer.onAdd();
    }

    static /* synthetic */ ReadWriteLock access$100(ClusterManager clusterManager) {
        return clusterManager.mAlgorithmLock;
    }

    static /* synthetic */ Algorithm access$200(ClusterManager clusterManager) {
        return clusterManager.mAlgorithm;
    }

    static /* synthetic */ ClusterRenderer access$300(ClusterManager clusterManager) {
        return clusterManager.mRenderer;
    }

    public void addItem(T t) {
        this.mAlgorithmLock.writeLock().lock();
        try {
            this.mAlgorithm.addItem(t);
            return;
        }
        finally {
            this.mAlgorithmLock.writeLock().unlock();
        }
    }

    public void addItems(Collection<T> collection) {
        this.mAlgorithmLock.writeLock().lock();
        try {
            this.mAlgorithm.addItems(collection);
            return;
        }
        finally {
            this.mAlgorithmLock.writeLock().unlock();
        }
    }

    public void clearItems() {
        this.mAlgorithmLock.writeLock().lock();
        try {
            this.mAlgorithm.clearItems();
            return;
        }
        finally {
            this.mAlgorithmLock.writeLock().unlock();
        }
    }

    public void cluster() {
        this.mClusterTaskLock.writeLock().lock();
        try {
            this.mClusterTask.cancel(true);
            this.mClusterTask = new /* Unavailable Anonymous Inner Class!! */;
            if (Build.VERSION.SDK_INT < 11) {
                ClusterManager<T> clusterManager = this.mClusterTask;
                Object[] arrobject = new Float[]{Float.valueOf((float)this.mMap.getCameraPosition().zoom)};
                clusterManager.execute(arrobject);
            } else {
                ClusterManager<T> clusterManager = this.mClusterTask;
                Executor executor = AsyncTask.THREAD_POOL_EXECUTOR;
                Object[] arrobject = new Float[]{Float.valueOf((float)this.mMap.getCameraPosition().zoom)};
                clusterManager.executeOnExecutor(executor, arrobject);
            }
            return;
        }
        finally {
            this.mClusterTaskLock.writeLock().unlock();
        }
    }

    public Algorithm<T> getAlgorithm() {
        return this.mAlgorithm;
    }

    public MarkerManager.Collection getClusterMarkerCollection() {
        return this.mClusterMarkers;
    }

    public MarkerManager.Collection getMarkerCollection() {
        return this.mMarkers;
    }

    public MarkerManager getMarkerManager() {
        return this.mMarkerManager;
    }

    public ClusterRenderer<T> getRenderer() {
        return this.mRenderer;
    }

    public void onCameraIdle() {
        if (this.mRenderer instanceof GoogleMap.OnCameraIdleListener) {
            ((GoogleMap.OnCameraIdleListener)this.mRenderer).onCameraIdle();
        }
        CameraPosition cameraPosition = this.mMap.getCameraPosition();
        if (this.mPreviousCameraPosition != null && this.mPreviousCameraPosition.zoom == cameraPosition.zoom) {
            return;
        }
        this.mPreviousCameraPosition = this.mMap.getCameraPosition();
        this.cluster();
    }

    public void onInfoWindowClick(Marker marker) {
        this.getMarkerManager().onInfoWindowClick(marker);
    }

    public boolean onMarkerClick(Marker marker) {
        return this.getMarkerManager().onMarkerClick(marker);
    }

    public void removeItem(T t) {
        this.mAlgorithmLock.writeLock().lock();
        try {
            this.mAlgorithm.removeItem(t);
            return;
        }
        finally {
            this.mAlgorithmLock.writeLock().unlock();
        }
    }

    public void setAlgorithm(Algorithm<T> algorithm) {
        this.mAlgorithmLock.writeLock().lock();
        try {
            if (this.mAlgorithm != null) {
                algorithm.addItems(this.mAlgorithm.getItems());
            }
            this.mAlgorithm = new PreCachingAlgorithmDecorator<T>(algorithm);
            this.cluster();
            return;
        }
        finally {
            this.mAlgorithmLock.writeLock().unlock();
        }
    }

    public void setOnClusterClickListener(OnClusterClickListener<T> onClusterClickListener) {
        this.mOnClusterClickListener = onClusterClickListener;
        this.mRenderer.setOnClusterClickListener(onClusterClickListener);
    }

    public void setOnClusterInfoWindowClickListener(OnClusterInfoWindowClickListener<T> onClusterInfoWindowClickListener) {
        this.mOnClusterInfoWindowClickListener = onClusterInfoWindowClickListener;
        this.mRenderer.setOnClusterInfoWindowClickListener(onClusterInfoWindowClickListener);
    }

    public void setOnClusterItemClickListener(OnClusterItemClickListener<T> onClusterItemClickListener) {
        this.mOnClusterItemClickListener = onClusterItemClickListener;
        this.mRenderer.setOnClusterItemClickListener(onClusterItemClickListener);
    }

    public void setOnClusterItemInfoWindowClickListener(OnClusterItemInfoWindowClickListener<T> onClusterItemInfoWindowClickListener) {
        this.mOnClusterItemInfoWindowClickListener = onClusterItemInfoWindowClickListener;
        this.mRenderer.setOnClusterItemInfoWindowClickListener(onClusterItemInfoWindowClickListener);
    }

    public void setRenderer(ClusterRenderer<T> clusterRenderer) {
        this.mRenderer.setOnClusterClickListener(null);
        this.mRenderer.setOnClusterItemClickListener(null);
        this.mClusterMarkers.clear();
        this.mMarkers.clear();
        this.mRenderer.onRemove();
        this.mRenderer = clusterRenderer;
        this.mRenderer.onAdd();
        this.mRenderer.setOnClusterClickListener(this.mOnClusterClickListener);
        this.mRenderer.setOnClusterInfoWindowClickListener(this.mOnClusterInfoWindowClickListener);
        this.mRenderer.setOnClusterItemClickListener(this.mOnClusterItemClickListener);
        this.mRenderer.setOnClusterItemInfoWindowClickListener(this.mOnClusterItemInfoWindowClickListener);
        this.cluster();
    }
}

