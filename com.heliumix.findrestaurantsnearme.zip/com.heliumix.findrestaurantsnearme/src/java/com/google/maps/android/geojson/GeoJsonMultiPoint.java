/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.maps.android.geojson.GeoJsonGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.google.maps.android.geojson;

import com.google.maps.android.geojson.GeoJsonGeometry;
import com.google.maps.android.geojson.GeoJsonPoint;
import java.util.List;

public class GeoJsonMultiPoint
implements GeoJsonGeometry {
    private static final String GEOMETRY_TYPE = "MultiPoint";
    private final List<GeoJsonPoint> mGeoJsonPoints;

    public GeoJsonMultiPoint(List<GeoJsonPoint> list) {
        if (list == null) {
            throw new IllegalArgumentException("GeoJsonPoints cannot be null");
        }
        this.mGeoJsonPoints = list;
    }

    public List<GeoJsonPoint> getPoints() {
        return this.mGeoJsonPoints;
    }

    public String getType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n points=");
        stringBuilder.append(this.mGeoJsonPoints);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

