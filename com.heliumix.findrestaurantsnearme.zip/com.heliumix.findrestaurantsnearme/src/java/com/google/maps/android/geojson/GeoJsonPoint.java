/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.geojson.GeoJsonGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.maps.android.geojson;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.geojson.GeoJsonGeometry;

public class GeoJsonPoint
implements GeoJsonGeometry {
    private static final String GEOMETRY_TYPE = "Point";
    private final LatLng mCoordinates;

    public GeoJsonPoint(LatLng latLng) {
        if (latLng == null) {
            throw new IllegalArgumentException("Coordinate cannot be null");
        }
        this.mCoordinates = latLng;
    }

    public LatLng getCoordinates() {
        return this.mCoordinates;
    }

    public String getType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n coordinates=");
        stringBuilder.append((Object)this.mCoordinates);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

