/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.BitmapDescriptor
 *  com.google.android.gms.maps.model.MarkerOptions
 *  com.google.maps.android.geojson.GeoJsonStyle
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Observable
 */
package com.google.maps.android.geojson;

import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.geojson.GeoJsonStyle;
import java.util.Arrays;
import java.util.Observable;

public class GeoJsonPointStyle
extends Observable
implements GeoJsonStyle {
    private static final String[] GEOMETRY_TYPE = new String[]{"Point", "MultiPoint", "GeometryCollection"};
    private final MarkerOptions mMarkerOptions = new MarkerOptions();

    private void styleChanged() {
        this.setChanged();
        this.notifyObservers();
    }

    public float getAlpha() {
        return this.mMarkerOptions.getAlpha();
    }

    public float getAnchorU() {
        return this.mMarkerOptions.getAnchorU();
    }

    public float getAnchorV() {
        return this.mMarkerOptions.getAnchorV();
    }

    public String[] getGeometryType() {
        return GEOMETRY_TYPE;
    }

    public BitmapDescriptor getIcon() {
        return this.mMarkerOptions.getIcon();
    }

    public float getInfoWindowAnchorU() {
        return this.mMarkerOptions.getInfoWindowAnchorU();
    }

    public float getInfoWindowAnchorV() {
        return this.mMarkerOptions.getInfoWindowAnchorV();
    }

    public float getRotation() {
        return this.mMarkerOptions.getRotation();
    }

    public String getSnippet() {
        return this.mMarkerOptions.getSnippet();
    }

    public String getTitle() {
        return this.mMarkerOptions.getTitle();
    }

    public boolean isDraggable() {
        return this.mMarkerOptions.isDraggable();
    }

    public boolean isFlat() {
        return this.mMarkerOptions.isFlat();
    }

    public boolean isVisible() {
        return this.mMarkerOptions.isVisible();
    }

    public void setAlpha(float f) {
        this.mMarkerOptions.alpha(f);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setAnchor(float f, float f2) {
        this.mMarkerOptions.anchor(f, f2);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setDraggable(boolean bl) {
        this.mMarkerOptions.draggable(bl);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setFlat(boolean bl) {
        this.mMarkerOptions.flat(bl);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setIcon(BitmapDescriptor bitmapDescriptor) {
        this.mMarkerOptions.icon(bitmapDescriptor);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setInfoWindowAnchor(float f, float f2) {
        this.mMarkerOptions.infoWindowAnchor(f, f2);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setRotation(float f) {
        this.mMarkerOptions.rotation(f);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setSnippet(String string) {
        this.mMarkerOptions.snippet(string);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setTitle(String string) {
        this.mMarkerOptions.title(string);
        GeoJsonPointStyle.super.styleChanged();
    }

    public void setVisible(boolean bl) {
        this.mMarkerOptions.visible(bl);
        GeoJsonPointStyle.super.styleChanged();
    }

    public MarkerOptions toMarkerOptions() {
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.alpha(this.mMarkerOptions.getAlpha());
        markerOptions.anchor(this.mMarkerOptions.getAnchorU(), this.mMarkerOptions.getAnchorV());
        markerOptions.draggable(this.mMarkerOptions.isDraggable());
        markerOptions.flat(this.mMarkerOptions.isFlat());
        markerOptions.icon(this.mMarkerOptions.getIcon());
        markerOptions.infoWindowAnchor(this.mMarkerOptions.getInfoWindowAnchorU(), this.mMarkerOptions.getInfoWindowAnchorV());
        markerOptions.rotation(this.mMarkerOptions.getRotation());
        markerOptions.snippet(this.mMarkerOptions.getSnippet());
        markerOptions.title(this.mMarkerOptions.getTitle());
        markerOptions.visible(this.mMarkerOptions.isVisible());
        return markerOptions;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("PointStyle{");
        stringBuilder.append("\n geometry type=");
        stringBuilder.append(Arrays.toString((Object[])GEOMETRY_TYPE));
        stringBuilder.append(",\n alpha=");
        stringBuilder.append(this.getAlpha());
        stringBuilder.append(",\n anchor U=");
        stringBuilder.append(this.getAnchorU());
        stringBuilder.append(",\n anchor V=");
        stringBuilder.append(this.getAnchorV());
        stringBuilder.append(",\n draggable=");
        stringBuilder.append(this.isDraggable());
        stringBuilder.append(",\n flat=");
        stringBuilder.append(this.isFlat());
        stringBuilder.append(",\n info window anchor U=");
        stringBuilder.append(this.getInfoWindowAnchorU());
        stringBuilder.append(",\n info window anchor V=");
        stringBuilder.append(this.getInfoWindowAnchorV());
        stringBuilder.append(",\n rotation=");
        stringBuilder.append(this.getRotation());
        stringBuilder.append(",\n snippet=");
        stringBuilder.append(this.getSnippet());
        stringBuilder.append(",\n title=");
        stringBuilder.append(this.getTitle());
        stringBuilder.append(",\n visible=");
        stringBuilder.append(this.isVisible());
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

