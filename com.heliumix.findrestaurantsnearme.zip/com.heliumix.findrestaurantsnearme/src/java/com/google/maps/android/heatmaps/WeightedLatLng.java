/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.geometry.Point
 *  com.google.maps.android.projection.SphericalMercatorProjection
 *  com.google.maps.android.quadtree.PointQuadTree
 *  com.google.maps.android.quadtree.PointQuadTree$Item
 *  java.lang.Object
 */
package com.google.maps.android.heatmaps;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.geometry.Point;
import com.google.maps.android.projection.SphericalMercatorProjection;
import com.google.maps.android.quadtree.PointQuadTree;

public class WeightedLatLng
implements PointQuadTree.Item {
    public static final double DEFAULT_INTENSITY = 1.0;
    private static final SphericalMercatorProjection sProjection = new SphericalMercatorProjection(1.0);
    private double mIntensity;
    private Point mPoint;

    public WeightedLatLng(LatLng latLng) {
        super(latLng, 1.0);
    }

    public WeightedLatLng(LatLng latLng, double d) {
        this.mPoint = sProjection.toPoint(latLng);
        if (d >= 0.0) {
            this.mIntensity = d;
            return;
        }
        this.mIntensity = 1.0;
    }

    public double getIntensity() {
        return this.mIntensity;
    }

    public Point getPoint() {
        return this.mPoint;
    }
}

