/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  D
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.Color
 *  android.support.v4.util.LongSparseArray
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.android.gms.maps.model.Tile
 *  com.google.android.gms.maps.model.TileProvider
 *  com.google.maps.android.geometry.Bounds
 *  com.google.maps.android.geometry.Point
 *  com.google.maps.android.heatmaps.Gradient
 *  com.google.maps.android.heatmaps.HeatmapTileProvider$1
 *  com.google.maps.android.heatmaps.HeatmapTileProvider$Builder
 *  com.google.maps.android.quadtree.PointQuadTree
 *  com.google.maps.android.quadtree.PointQuadTree$Item
 *  java.io.ByteArrayOutputStream
 *  java.io.OutputStream
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Array
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 */
package com.google.maps.android.heatmaps;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.v4.util.LongSparseArray;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Tile;
import com.google.android.gms.maps.model.TileProvider;
import com.google.maps.android.geometry.Bounds;
import com.google.maps.android.geometry.Point;
import com.google.maps.android.heatmaps.Gradient;
import com.google.maps.android.heatmaps.HeatmapTileProvider;
import com.google.maps.android.heatmaps.WeightedLatLng;
import com.google.maps.android.quadtree.PointQuadTree;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/*
 * Exception performing whole class analysis ignored.
 */
public class HeatmapTileProvider
implements TileProvider {
    public static final Gradient DEFAULT_GRADIENT;
    private static final int[] DEFAULT_GRADIENT_COLORS;
    private static final float[] DEFAULT_GRADIENT_START_POINTS;
    private static final int DEFAULT_MAX_ZOOM = 11;
    private static final int DEFAULT_MIN_ZOOM = 5;
    public static final double DEFAULT_OPACITY = 0.7;
    public static final int DEFAULT_RADIUS = 20;
    private static final int MAX_RADIUS = 50;
    private static final int MAX_ZOOM_LEVEL = 22;
    private static final int MIN_RADIUS = 10;
    private static final int SCREEN_SIZE = 1280;
    private static final int TILE_DIM = 512;
    static final double WORLD_WIDTH = 1.0;
    private Bounds mBounds;
    private int[] mColorMap;
    private Collection<WeightedLatLng> mData;
    private Gradient mGradient;
    private double[] mKernel;
    private double[] mMaxIntensity;
    private double mOpacity;
    private int mRadius;
    private PointQuadTree<WeightedLatLng> mTree;

    static {
        int[] arrn = new int[]{Color.rgb((int)102, (int)225, (int)0), Color.rgb((int)255, (int)0, (int)0)};
        DEFAULT_GRADIENT_COLORS = arrn;
        DEFAULT_GRADIENT_START_POINTS = new float[]{0.2f, 1.0f};
        DEFAULT_GRADIENT = new Gradient(DEFAULT_GRADIENT_COLORS, DEFAULT_GRADIENT_START_POINTS);
    }

    private HeatmapTileProvider(Builder builder) {
        this.mData = Builder.access$200(builder);
        this.mRadius = Builder.access$300(builder);
        this.mGradient = Builder.access$400(builder);
        this.mOpacity = Builder.access$500(builder);
        this.mKernel = HeatmapTileProvider.generateKernel(this.mRadius, (double)this.mRadius / 3.0);
        this.setGradient(this.mGradient);
        this.setWeightedData(this.mData);
    }

    /* synthetic */ HeatmapTileProvider(Builder builder, 1 var2_2) {
        super(builder);
    }

    static /* synthetic */ Collection access$000(Collection collection) {
        return HeatmapTileProvider.wrapData((Collection<LatLng>)collection);
    }

    static Bitmap colorize(double[][] arrd, int[] arrn, double d) {
        int n = arrn[-1 + arrn.length];
        double d2 = (double)(-1 + arrn.length) / d;
        int n2 = arrd.length;
        int[] arrn2 = new int[n2 * n2];
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n2; ++j) {
                double d3 = arrd[j][i];
                int n3 = j + i * n2;
                int n4 = (int)(d3 * d2);
                if (d3 != 0.0) {
                    if (n4 < arrn.length) {
                        arrn2[n3] = arrn[n4];
                        continue;
                    }
                    arrn2[n3] = n;
                    continue;
                }
                arrn2[n3] = 0;
            }
        }
        Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        bitmap.setPixels(arrn2, 0, n2, 0, 0, n2, n2);
        return bitmap;
    }

    private static Tile convertBitmap(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)byteArrayOutputStream);
        return new Tile(512, 512, byteArrayOutputStream.toByteArray());
    }

    static double[][] convolve(double[][] arrd, double[] arrd2) {
        int n = (int)Math.floor((double)((double)arrd2.length / 2.0));
        int n2 = arrd.length;
        int n3 = n2 - n * 2;
        int n4 = -1 + (n + n3);
        double[][] arrd3 = (double[][])Array.newInstance(D.class, (int[])new int[]{n2, n2});
        for (int i = 0; i < n2; ++i) {
            for (int j = 0; j < n2; ++j) {
                double d = arrd[i][j];
                if (d == 0.0) continue;
                int n5 = i + n;
                if (n4 < n5) {
                    n5 = n4;
                }
                int n6 = n5 + 1;
                int n7 = i - n;
                int n8 = n > n7 ? n : n7;
                for (int k = n8; k < n6; ++k) {
                    double[] arrd4 = arrd3[k];
                    arrd4[j] = arrd4[j] + d * arrd2[k - n7];
                }
            }
        }
        double[][] arrd5 = (double[][])Array.newInstance(D.class, (int[])new int[]{n3, n3});
        for (int i = n; i < n4 + 1; ++i) {
            for (int j = 0; j < n2; ++j) {
                double d = arrd3[i][j];
                if (d == 0.0) continue;
                int n9 = j + n;
                if (n4 < n9) {
                    n9 = n4;
                }
                int n10 = n9 + 1;
                for (int k = n > (n11 = j - n) ? n : n11; k < n10; ++k) {
                    int n11;
                    double[] arrd6 = arrd5[i - n];
                    int n12 = k - n;
                    arrd6[n12] = arrd6[n12] + d * arrd2[k - n11];
                }
            }
        }
        return arrd5;
    }

    static double[] generateKernel(int n, double d) {
        double[] arrd = new double[1 + n * 2];
        for (int i = -n; i <= n; ++i) {
            arrd[i + n] = Math.exp((double)((double)(i * -i) / (d * (2.0 * d))));
        }
        return arrd;
    }

    static Bounds getBounds(Collection<WeightedLatLng> collection) {
        Iterator iterator = collection.iterator();
        WeightedLatLng weightedLatLng = (WeightedLatLng)iterator.next();
        double d = weightedLatLng.getPoint().x;
        double d2 = weightedLatLng.getPoint().x;
        double d3 = weightedLatLng.getPoint().y;
        double d4 = weightedLatLng.getPoint().y;
        double d5 = d;
        double d6 = d2;
        double d7 = d3;
        double d8 = d4;
        while (iterator.hasNext()) {
            WeightedLatLng weightedLatLng2 = (WeightedLatLng)iterator.next();
            double d9 = weightedLatLng2.getPoint().x;
            double d10 = weightedLatLng2.getPoint().y;
            if (d9 < d5) {
                d5 = d9;
            }
            if (d9 > d6) {
                d6 = d9;
            }
            if (d10 < d7) {
                d7 = d10;
            }
            if (!(d10 > d8)) continue;
            d8 = d10;
        }
        Bounds bounds = new Bounds(d5, d6, d7, d8);
        return bounds;
    }

    private double[] getMaxIntensities(int n) {
        int n2;
        double[] arrd = new double[22];
        for (int i = 5; i < (n2 = 11); ++i) {
            arrd[i] = HeatmapTileProvider.getMaxValue(this.mData, this.mBounds, n, (int)(1280.0 * Math.pow((double)2.0, (double)(i - 3))));
            if (i != 5) continue;
            for (int j = 0; j < i; ++j) {
                arrd[j] = arrd[i];
            }
        }
        while (n2 < 22) {
            arrd[n2] = arrd[10];
            ++n2;
        }
        return arrd;
    }

    static double getMaxValue(Collection<WeightedLatLng> collection, Bounds bounds, int n, int n2) {
        double d = bounds.maxX;
        double d2 = bounds.minX;
        double d3 = d - d2;
        double d4 = bounds.maxY;
        double d5 = bounds.minY;
        double d6 = d4 - d5;
        if (!(d3 > d6)) {
            d3 = d6;
        }
        double d7 = (double)((int)(0.5 + (double)(n2 / (n * 2)))) / d3;
        LongSparseArray longSparseArray = new LongSparseArray();
        Iterator iterator = collection.iterator();
        double d8 = 0.0;
        while (iterator.hasNext()) {
            double d9;
            LongSparseArray longSparseArray2;
            Double d10;
            long l;
            WeightedLatLng weightedLatLng = (WeightedLatLng)iterator.next();
            double d11 = weightedLatLng.getPoint().x;
            double d12 = weightedLatLng.getPoint().y;
            int n3 = (int)(d7 * (d11 - d2));
            int n4 = (int)(d7 * (d12 - d5));
            long l2 = n3;
            LongSparseArray longSparseArray3 = (LongSparseArray)longSparseArray.get(l2);
            if (longSparseArray3 == null) {
                longSparseArray3 = new LongSparseArray();
                longSparseArray.put(l2, (Object)longSparseArray3);
            }
            if ((d10 = (Double)longSparseArray3.get(l = (long)n4)) == null) {
                longSparseArray2 = longSparseArray;
                d9 = d2;
                d10 = 0.0;
            } else {
                longSparseArray2 = longSparseArray;
                d9 = d2;
            }
            Double d13 = d10 + weightedLatLng.getIntensity();
            longSparseArray3.put(l, (Object)d13);
            if (d13 > d8) {
                d8 = d13;
            }
            d2 = d9;
            longSparseArray = longSparseArray2;
        }
        return d8;
    }

    private static Collection<WeightedLatLng> wrapData(Collection<LatLng> collection) {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)new WeightedLatLng((LatLng)iterator.next()));
        }
        return arrayList;
    }

    public Tile getTile(int n, int n2, int n3) {
        double d = Math.pow((double)2.0, (double)n3);
        double d2 = 1.0;
        double d3 = d2 / d;
        double d4 = d3 * (double)this.mRadius / 512.0;
        double d5 = (d3 + 2.0 * d4) / (double)(512 + 2 * this.mRadius);
        double d6 = d3 * (double)n - d4;
        double d7 = d4 + d3 * (double)(n + 1);
        double d8 = d3 * (double)n2 - d4;
        double d9 = d4 + d3 * (double)(n2 + 1);
        ArrayList arrayList = new ArrayList();
        if (d6 < 0.0) {
            Bounds bounds = new Bounds(d6 + d2, 1.0, d8, d9);
            d2 = -1.0;
            arrayList = this.mTree.search(bounds);
        } else if (d7 > d2) {
            Bounds bounds = new Bounds(0.0, d7 - d2, d8, d9);
            arrayList = this.mTree.search(bounds);
        } else {
            d2 = 0.0;
        }
        Bounds bounds = new Bounds(d6, d7, d8, d9);
        Bounds bounds2 = new Bounds(this.mBounds.minX - d4, d4 + this.mBounds.maxX, this.mBounds.minY - d4, d4 + this.mBounds.maxY);
        if (!bounds.intersects(bounds2)) {
            return TileProvider.NO_TILE;
        }
        Collection collection = this.mTree.search(bounds);
        if (collection.isEmpty()) {
            return TileProvider.NO_TILE;
        }
        double[][] arrd = (double[][])Array.newInstance(D.class, (int[])new int[]{512 + 2 * this.mRadius, 512 + 2 * this.mRadius});
        for (WeightedLatLng weightedLatLng : collection) {
            Point point = weightedLatLng.getPoint();
            int n4 = (int)((point.x - d6) / d5);
            int n5 = (int)((point.y - d8) / d5);
            double[] arrd2 = arrd[n4];
            arrd2[n5] = arrd2[n5] + weightedLatLng.getIntensity();
        }
        for (WeightedLatLng weightedLatLng : arrayList) {
            Point point = weightedLatLng.getPoint();
            int n6 = (int)((d2 + point.x - d6) / d5);
            int n7 = (int)((point.y - d8) / d5);
            double[] arrd3 = arrd[n6];
            arrd3[n7] = arrd3[n7] + weightedLatLng.getIntensity();
        }
        return HeatmapTileProvider.convertBitmap(HeatmapTileProvider.colorize(HeatmapTileProvider.convolve(arrd, this.mKernel), this.mColorMap, this.mMaxIntensity[n3]));
    }

    public void setData(Collection<LatLng> collection) {
        this.setWeightedData(HeatmapTileProvider.wrapData(collection));
    }

    public void setGradient(Gradient gradient) {
        this.mGradient = gradient;
        this.mColorMap = gradient.generateColorMap(this.mOpacity);
    }

    public void setOpacity(double d) {
        this.mOpacity = d;
        this.setGradient(this.mGradient);
    }

    public void setRadius(int n) {
        this.mRadius = n;
        this.mKernel = HeatmapTileProvider.generateKernel(this.mRadius, (double)this.mRadius / 3.0);
        this.mMaxIntensity = HeatmapTileProvider.super.getMaxIntensities(this.mRadius);
    }

    public void setWeightedData(Collection<WeightedLatLng> collection) {
        this.mData = collection;
        if (this.mData.isEmpty()) {
            throw new IllegalArgumentException("No input points.");
        }
        this.mBounds = HeatmapTileProvider.getBounds(this.mData);
        this.mTree = new PointQuadTree(this.mBounds);
        for (WeightedLatLng weightedLatLng : this.mData) {
            this.mTree.add((PointQuadTree.Item)weightedLatLng);
        }
        this.mMaxIntensity = HeatmapTileProvider.super.getMaxIntensities(this.mRadius);
    }
}

