/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.kml.KmlGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.maps.android.kml;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.kml.KmlGeometry;
import java.util.ArrayList;
import java.util.List;

public class KmlLineString
implements KmlGeometry<List<LatLng>> {
    public static final String GEOMETRY_TYPE = "LineString";
    final ArrayList<LatLng> mCoordinates;

    public KmlLineString(ArrayList<LatLng> arrayList) {
        if (arrayList == null) {
            throw new IllegalArgumentException("Coordinates cannot be null");
        }
        this.mCoordinates = arrayList;
    }

    public ArrayList<LatLng> getGeometryObject() {
        return this.mCoordinates;
    }

    public String getGeometryType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n coordinates=");
        stringBuilder.append(this.mCoordinates);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

