/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.maps.android.geojson.GeoJsonGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.google.maps.android.geojson;

import com.google.maps.android.geojson.GeoJsonGeometry;
import com.google.maps.android.geojson.GeoJsonPolygon;
import java.util.List;

public class GeoJsonMultiPolygon
implements GeoJsonGeometry {
    private static final String GEOMETRY_TYPE = "MultiPolygon";
    private final List<GeoJsonPolygon> mGeoJsonPolygons;

    public GeoJsonMultiPolygon(List<GeoJsonPolygon> list) {
        if (list == null) {
            throw new IllegalArgumentException("GeoJsonPolygons cannot be null");
        }
        this.mGeoJsonPolygons = list;
    }

    public List<GeoJsonPolygon> getPolygons() {
        return this.mGeoJsonPolygons;
    }

    public String getType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n Polygons=");
        stringBuilder.append(this.mGeoJsonPolygons);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

