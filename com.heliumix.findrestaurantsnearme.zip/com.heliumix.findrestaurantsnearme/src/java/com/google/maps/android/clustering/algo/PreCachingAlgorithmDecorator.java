/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.util.LruCache
 *  com.google.maps.android.clustering.Cluster
 *  com.google.maps.android.clustering.ClusterItem
 *  com.google.maps.android.clustering.algo.Algorithm
 *  com.google.maps.android.clustering.algo.PreCachingAlgorithmDecorator$PrecacheRunnable
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.Thread
 *  java.util.Collection
 *  java.util.Set
 *  java.util.concurrent.locks.Lock
 *  java.util.concurrent.locks.ReadWriteLock
 *  java.util.concurrent.locks.ReentrantReadWriteLock
 */
package com.google.maps.android.clustering.algo;

import android.support.v4.util.LruCache;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterItem;
import com.google.maps.android.clustering.algo.Algorithm;
import com.google.maps.android.clustering.algo.PreCachingAlgorithmDecorator;
import java.util.Collection;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/*
 * Exception performing whole class analysis.
 */
public class PreCachingAlgorithmDecorator<T extends ClusterItem>
implements Algorithm<T> {
    private final Algorithm<T> mAlgorithm;
    private final LruCache<Integer, Set<? extends Cluster<T>>> mCache;
    private final ReadWriteLock mCacheLock;

    public PreCachingAlgorithmDecorator(Algorithm<T> algorithm) {
        this.mCache = new LruCache(5);
        this.mCacheLock = new ReentrantReadWriteLock();
        this.mAlgorithm = algorithm;
    }

    static /* synthetic */ Set access$000(PreCachingAlgorithmDecorator preCachingAlgorithmDecorator, int n) {
        return preCachingAlgorithmDecorator.getClustersInternal(n);
    }

    private void clearCache() {
        this.mCache.evictAll();
    }

    private Set<? extends Cluster<T>> getClustersInternal(int n) {
        this.mCacheLock.readLock().lock();
        Set set = (Set)this.mCache.get((Object)n);
        this.mCacheLock.readLock().unlock();
        if (set == null) {
            this.mCacheLock.writeLock().lock();
            set = (Set)this.mCache.get((Object)n);
            if (set == null) {
                set = this.mAlgorithm.getClusters((double)n);
                this.mCache.put((Object)n, (Object)set);
            }
            this.mCacheLock.writeLock().unlock();
        }
        return set;
    }

    public void addItem(T t) {
        this.mAlgorithm.addItem(t);
        PreCachingAlgorithmDecorator.super.clearCache();
    }

    public void addItems(Collection<T> collection) {
        this.mAlgorithm.addItems(collection);
        PreCachingAlgorithmDecorator.super.clearCache();
    }

    public void clearItems() {
        this.mAlgorithm.clearItems();
        this.clearCache();
    }

    public Set<? extends Cluster<T>> getClusters(double d) {
        LruCache<Integer, Set<? extends Cluster<T>>> lruCache;
        int n;
        int n2 = (int)d;
        Set<Cluster<T>> set = PreCachingAlgorithmDecorator.super.getClustersInternal(n2);
        LruCache<Integer, Set<? extends Cluster<T>>> lruCache2 = this.mCache;
        int n3 = n2 + 1;
        if (lruCache2.get((Object)n3) == null) {
            new Thread((Runnable)new /* Unavailable Anonymous Inner Class!! */).start();
        }
        if ((lruCache = this.mCache).get((Object)(n = n2 - 1)) == null) {
            new Thread((Runnable)new /* Unavailable Anonymous Inner Class!! */).start();
        }
        return set;
    }

    public Collection<T> getItems() {
        return this.mAlgorithm.getItems();
    }

    public void removeItem(T t) {
        this.mAlgorithm.removeItem(t);
        PreCachingAlgorithmDecorator.super.clearCache();
    }
}

