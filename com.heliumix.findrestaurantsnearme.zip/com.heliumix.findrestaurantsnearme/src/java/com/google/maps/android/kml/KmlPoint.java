/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.kml.KmlGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.maps.android.kml;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.kml.KmlGeometry;

public class KmlPoint
implements KmlGeometry<LatLng> {
    public static final String GEOMETRY_TYPE = "Point";
    private final LatLng mCoordinate;

    public KmlPoint(LatLng latLng) {
        if (latLng == null) {
            throw new IllegalArgumentException("Coordinates cannot be null");
        }
        this.mCoordinate = latLng;
    }

    public LatLng getGeometryObject() {
        return this.mCoordinate;
    }

    public String getGeometryType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n coordinates=");
        stringBuilder.append((Object)this.mCoordinate);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

