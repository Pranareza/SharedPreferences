/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.clustering.Cluster
 *  com.google.maps.android.clustering.ClusterItem
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 */
package com.google.maps.android.clustering.algo;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterItem;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class StaticCluster<T extends ClusterItem>
implements Cluster<T> {
    private final LatLng mCenter;
    private final List<T> mItems = new ArrayList();

    public StaticCluster(LatLng latLng) {
        this.mCenter = latLng;
    }

    public boolean add(T t) {
        return this.mItems.add(t);
    }

    public boolean equals(Object object) {
        if (!(object instanceof StaticCluster)) {
            return false;
        }
        StaticCluster staticCluster = (StaticCluster)object;
        boolean bl = staticCluster.mCenter.equals((Object)this.mCenter);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = staticCluster.mItems.equals(this.mItems);
            bl2 = false;
            if (bl3) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public Collection<T> getItems() {
        return this.mItems;
    }

    public LatLng getPosition() {
        return this.mCenter;
    }

    public int getSize() {
        return this.mItems.size();
    }

    public int hashCode() {
        return this.mCenter.hashCode() + this.mItems.hashCode();
    }

    public boolean remove(T t) {
        return this.mItems.remove(t);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("StaticCluster{mCenter=");
        stringBuilder.append((Object)this.mCenter);
        stringBuilder.append(", mItems.size=");
        stringBuilder.append(this.mItems.size());
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

