/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.util.LongSparseArray
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.clustering.Cluster
 *  com.google.maps.android.clustering.ClusterItem
 *  com.google.maps.android.clustering.algo.Algorithm
 *  com.google.maps.android.geometry.Point
 *  com.google.maps.android.projection.SphericalMercatorProjection
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 */
package com.google.maps.android.clustering.algo;

import android.support.v4.util.LongSparseArray;
import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterItem;
import com.google.maps.android.clustering.algo.Algorithm;
import com.google.maps.android.clustering.algo.StaticCluster;
import com.google.maps.android.geometry.Point;
import com.google.maps.android.projection.SphericalMercatorProjection;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class GridBasedAlgorithm<T extends ClusterItem>
implements Algorithm<T> {
    private static final int GRID_SIZE = 100;
    private final Set<T> mItems = Collections.synchronizedSet((Set)new HashSet());

    private static long getCoord(long l, double d, double d2) {
        return (long)((double)l * Math.floor((double)d) + Math.floor((double)d2));
    }

    public void addItem(T t) {
        this.mItems.add(t);
    }

    public void addItems(Collection<T> collection) {
        this.mItems.addAll(collection);
    }

    public void clearItems() {
        this.mItems.clear();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Set<? extends Cluster<T>> getClusters(double d) {
        Set<T> set;
        long l = (long)Math.ceil((double)(256.0 * Math.pow((double)2.0, (double)d) / 100.0));
        SphericalMercatorProjection sphericalMercatorProjection = new SphericalMercatorProjection((double)l);
        HashSet hashSet = new HashSet();
        LongSparseArray longSparseArray = new LongSparseArray();
        Set<T> set2 = set = this.mItems;
        synchronized (set2) {
            Iterator iterator = this.mItems.iterator();
            while (iterator.hasNext()) {
                long l2;
                ClusterItem clusterItem = (ClusterItem)iterator.next();
                com.google.maps.android.projection.Point point = sphericalMercatorProjection.toPoint(clusterItem.getPosition());
                double d2 = point.x;
                double d3 = point.y;
                long l3 = GridBasedAlgorithm.getCoord(l, d2, d3);
                StaticCluster<ClusterItem> staticCluster = (StaticCluster<ClusterItem>)longSparseArray.get(l3);
                if (staticCluster == null) {
                    double d4 = 0.5 + Math.floor((double)point.x);
                    l2 = l;
                    staticCluster = new StaticCluster<ClusterItem>(sphericalMercatorProjection.toLatLng(new Point(d4, 0.5 + Math.floor((double)point.y))));
                    longSparseArray.put(l3, staticCluster);
                    hashSet.add(staticCluster);
                } else {
                    l2 = l;
                }
                staticCluster.add(clusterItem);
                l = l2;
            }
            return hashSet;
        }
    }

    public Collection<T> getItems() {
        return this.mItems;
    }

    public void removeItem(T t) {
        this.mItems.remove(t);
    }
}

