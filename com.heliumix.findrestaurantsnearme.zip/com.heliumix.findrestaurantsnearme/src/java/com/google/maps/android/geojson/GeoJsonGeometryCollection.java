/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.maps.android.geojson.GeoJsonGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.google.maps.android.geojson;

import com.google.maps.android.geojson.GeoJsonGeometry;
import java.util.List;

public class GeoJsonGeometryCollection
implements GeoJsonGeometry {
    private static final String GEOMETRY_TYPE = "GeometryCollection";
    private final List<GeoJsonGeometry> mGeometries;

    public GeoJsonGeometryCollection(List<GeoJsonGeometry> list) {
        if (list == null) {
            throw new IllegalArgumentException("Geometries cannot be null");
        }
        this.mGeometries = list;
    }

    public List<GeoJsonGeometry> getGeometries() {
        return this.mGeometries;
    }

    public String getType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n Geometries=");
        stringBuilder.append(this.mGeometries);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

