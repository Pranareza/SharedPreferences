/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.maps.android.geojson.GeoJsonGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.google.maps.android.geojson;

import com.google.maps.android.geojson.GeoJsonGeometry;
import com.google.maps.android.geojson.GeoJsonLineString;
import java.util.List;

public class GeoJsonMultiLineString
implements GeoJsonGeometry {
    private static final String GEOMETRY_TYPE = "MultiLineString";
    private final List<GeoJsonLineString> mGeoJsonLineStrings;

    public GeoJsonMultiLineString(List<GeoJsonLineString> list) {
        if (list == null) {
            throw new IllegalArgumentException("GeoJsonLineStrings cannot be null");
        }
        this.mGeoJsonLineStrings = list;
    }

    public List<GeoJsonLineString> getLineStrings() {
        return this.mGeoJsonLineStrings;
    }

    public String getType() {
        return GEOMETRY_TYPE;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n LineStrings=");
        stringBuilder.append(this.mGeoJsonLineStrings);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

