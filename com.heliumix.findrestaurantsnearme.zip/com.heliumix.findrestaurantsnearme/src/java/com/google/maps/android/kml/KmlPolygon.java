/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.maps.model.LatLng
 *  com.google.maps.android.kml.KmlGeometry
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 */
package com.google.maps.android.kml;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.kml.KmlGeometry;
import java.util.ArrayList;
import java.util.Collection;

public class KmlPolygon
implements KmlGeometry<ArrayList<ArrayList<LatLng>>> {
    public static final String GEOMETRY_TYPE = "Polygon";
    private final ArrayList<ArrayList<LatLng>> mInnerBoundaryCoordinates;
    private final ArrayList<LatLng> mOuterBoundaryCoordinates;

    public KmlPolygon(ArrayList<LatLng> arrayList, ArrayList<ArrayList<LatLng>> arrayList2) {
        if (arrayList == null) {
            throw new IllegalArgumentException("Outer boundary coordinates cannot be null");
        }
        this.mOuterBoundaryCoordinates = arrayList;
        this.mInnerBoundaryCoordinates = arrayList2;
    }

    public ArrayList<ArrayList<LatLng>> getGeometryObject() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(this.mOuterBoundaryCoordinates);
        if (this.mInnerBoundaryCoordinates != null) {
            arrayList.addAll(this.mInnerBoundaryCoordinates);
        }
        return arrayList;
    }

    public String getGeometryType() {
        return GEOMETRY_TYPE;
    }

    public ArrayList<ArrayList<LatLng>> getInnerBoundaryCoordinates() {
        return this.mInnerBoundaryCoordinates;
    }

    public ArrayList<LatLng> getOuterBoundaryCoordinates() {
        return this.mOuterBoundaryCoordinates;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(GEOMETRY_TYPE);
        stringBuilder.append("{");
        stringBuilder.append("\n outer coordinates=");
        stringBuilder.append(this.mOuterBoundaryCoordinates);
        stringBuilder.append(",\n inner coordinates=");
        stringBuilder.append(this.mInnerBoundaryCoordinates);
        stringBuilder.append("\n}\n");
        return stringBuilder.toString();
    }
}

