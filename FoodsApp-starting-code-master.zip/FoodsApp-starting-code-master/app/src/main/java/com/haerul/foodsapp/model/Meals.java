/*-----------------------------------------------------------------------------
 - Developed by Haerul Muttaqin                                               -
 - Last modified 3/17/19 5:24 AM                                              -
 - Subscribe : https://www.youtube.com/haerulmuttaqin                         -
 - Copyright (c) 2019. All rights reserved                                    -
 -----------------------------------------------------------------------------*/
package com.haerul.foodsapp.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Meals {

    /*
     * TODO 8 Paste the generated results
     *
     * Paste the generated results from -
     * http://www.jsonschema2pojo.org/
     */

    public class Meal {
        /*
         * TODO 9 Paste the generated results
         *
         * Paste the generated results Level 2 (Meal Item) from -
         * http://www.jsonschema2pojo.org/
         */
    }
}
